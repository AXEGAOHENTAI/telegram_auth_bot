# Пример структуры папки accounts

Эта папка содержит пример того, как должны быть организованы данные аккаунтов Steam.

## Структура

```
accounts/
├── account_name_1/
│   └── Steamguard.txt
├── account_name_2/
│   └── Steamguard.txt
└── README.md
```

## Файл Steamguard.txt

Файл `Steamguard.txt` должен содержать JSON с данными Steam Guard:

```json
{
    "shared_secret": "ваш_shared_secret_здесь",
    "identity_secret": "ваш_identity_secret_здесь",
    "device_id": "ваш_device_id_здесь"
}
```

## Важно!

- **НЕ добавляйте** папку `accounts/` в Git репозиторий
- **НЕ публикуйте** файлы `Steamguard.txt` в открытом доступе
- Эти данные конфиденциальны и должны храниться только локально

## Альтернативная папка

Бот также поддерживает папку `accountStash/` с аналогичной структурой. 